import matplotlib.pyplot as plt
import numpy as np

x = np.arange(10)
y = x**2

plt.figure(figsize=(12,8))
plt.xlabel("X")
plt.ylabel("Y")
plt.scatter(x,y,c="red",marker="+")
plt.show()