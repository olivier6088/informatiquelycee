import matplotlib.pyplot as plt
import numpy as np
x = np.arange(10)
y_1 = x**2
y_2 = x*np.log2(x)
y_3 = x**3

plt.figure(figsize=(6,6))
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Graphe 1")
plt.scatter(x,y_1,c="red",marker="+",label="x^2")
plt.scatter(x,y_2,c="black",marker="x", label="xlog2(x)")
plt.legend()
plt.savefig("fig1.png")

plt.figure(figsize=(6,6))
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Graphe 2")
plt.scatter(x,y_3,c="green",marker="+",label="x^3")
plt.legend()
plt.savefig("fig2.png")
plt.show()