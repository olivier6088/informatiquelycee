import pandas as pd
import matplotlib.pyplot as plt

dataset = pd.read_csv("pointage.csv")

t = dataset["t"].tolist()
x = dataset["x"].tolist()
y = dataset["y"].tolist()

plt.figure(figsize=(8,8))
plt.xlabel("X")
plt.ylabel("Y")
plt.scatter(x,y,marker="+")
plt.show()
