import pandas as pd

dataset = pd.read_csv("pointage.csv")

#tapez dataset dans la console