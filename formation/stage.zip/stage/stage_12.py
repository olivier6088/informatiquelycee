import matplotlib.pyplot as plt
import numpy as np
import math

g = 9.81
x0 = 0
z0 = 0
v0 = 30
alpha_deg = 70
alhpa_rad = (alpha_deg*math.pi)/180
Dt = 0.1
tab_x=[]
tab_z=[]

for t in np.arange(0,20,Dt) :
    x = v0*math.cos(alhpa_rad)*t+x0
    z = -0.5*g*t**2+v0*math.sin(alhpa_rad)*t+z0
    if z>=0:
        tab_x.append(x)
        tab_z.append(z)

plt.figure(figsize=(8,8))
plt.xlabel("x")
plt.ylabel("z")
plt.axis('equal')
plt.scatter(tab_x,tab_z,marker="+")
plt.show()