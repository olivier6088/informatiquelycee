import math
import numpy as np

g = 9.81
x0 = 0
z0 = 0
v0 = 10
alpha_deg = 80
Dt = 0.05

def rad(alpha_deg):
    return (alpha_deg*math.pi)/180

def calcul_traj(alhpa_rad,x0,z0,v0,g, Dt):
    tab_x=[]
    tab_z=[]
    for t in np.arange(0,20,Dt) :
        x = v0*math.cos(alhpa_rad)*t+x0
        z = -0.5*g*t**2+v0*math.sin(alhpa_rad)*t+z0
        if z>=0:
            tab_x.append(x)
            tab_z.append(z)
    return (tab_x, tab_z)

def calcul_vit(tab_x,tab_z,Dt):
    tab_vx=[]
    tab_vz=[]
    tab_v=[]
    for i in range(1,len(tab_x)-1):
        vx = (tab_x[i+1]-tab_x[i-1])/(2*Dt)
        vz = (tab_z[i+1]-tab_z[i-1])/(2*Dt)
        tab_vx.append(vx)
        tab_vz.append(vz)
        tab_v.append((math.sqrt(vx**2+vz**2)))
    return (tab_vx,tab_vz,tab_v)   

def calcul_acc(tab_vx,tab_vz,Dt):
    tab_ax=[]
    tab_az=[]
    tab_a=[]
    for i in range(1,len(tab_vx)-1):
        ax = (tab_vx[i+1]-tab_vx[i-1])/(2*Dt)
        az = (tab_vz[i+1]-tab_vz[i-1])/(2*Dt)
        tab_ax.append(ax)
        tab_az.append(az)
        tab_a.append(math.sqrt(ax**2+az**2))
    return (tab_ax,tab_az,tab_a)  

x, z = calcul_traj(rad(alpha_deg),x0,z0,v0,g, Dt)
vx,vz,v=calcul_vit(x,z,Dt)
ax,az,a=calcul_acc(vx,vz,Dt)