import matplotlib.pyplot as plt
import numpy as np
import math

g = 9.81
x0 = 0
z0 = 0
v0 = 10
m = 5
forceX = 0
forceZ = -m*g
alpha_deg = 80
nb_mesure=40
Dt = 0.05

def rad(alpha_deg):
    return (alpha_deg*math.pi)/180

vx=np.zeros(nb_mesure)
vz=np.zeros(nb_mesure)
vx[0]=v0*math.cos(rad(alpha_deg))
vz[0]=v0*math.sin(rad(alpha_deg))
for i in range(1,nb_mesure):
    vx[i]=vx[i-1]+(forceX/m)*Dt
    vz[i]=vz[i-1]+(forceZ/m)*Dt

x=np.zeros(nb_mesure)
z=np.zeros(nb_mesure)
x[0]=x0
z[0]=z0
for i in range(1,nb_mesure):
    x[i]=x[i-1]+vx[i]*Dt
    z[i]=z[i-1]+vz[i]*Dt    

plt.figure(figsize=(8,8))
plt.xlabel("x")
plt.ylabel("z")
plt.axis('equal')
plt.scatter(x,z,marker="+")



