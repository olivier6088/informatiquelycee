import pandas as pd
import matplotlib.pyplot as plt
import math

dataset = pd.read_csv("pointage.csv")

t = dataset["t"].tolist()
x = dataset["x"].tolist()
y = dataset["y"].tolist()

def calcul_vit(tab_x,tab_y,Dt):
    tab_vx=[]
    tab_vy=[]
    tab_v=[]
    for i in range(1,len(tab_x)-1):
        vx = (tab_x[i+1]-tab_x[i-1])/(2*Dt)
        vy = (tab_y[i+1]-tab_y[i-1])/(2*Dt)
        tab_vx.append(vx)
        tab_vy.append(vy)
        tab_v.append((math.sqrt(vx**2+vy**2)))
    return (tab_vx,tab_vy,tab_v)

Dt = (t[1]-t[0])*1e-3
vx, vy, v = calcul_vit(x,y,Dt)

plt.figure(figsize=(8,8))
plt.xlabel("X")
plt.ylabel("Y")
plt.scatter(x,y,marker="+")
plt.show()
