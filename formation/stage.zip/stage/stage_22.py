import pandas as pd

dataset = pd.read_csv("pointage.csv")

tab_t = dataset["t"].tolist()
tab_x = dataset["x"].tolist()
tab_y = dataset["y"].tolist()