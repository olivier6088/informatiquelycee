import matplotlib.pyplot as plt

x_1 = 0
y_1 = 0
x_2 = 1
y_2 = 2

dx_1 = 3
dy_1 = -2
dx_2 = 4
dy_2 = 1

plt.figure(figsize=(8,8))
plt.xlim(-5,5)
plt.ylim(-5,5)
plt.quiver(x_1,y_1, dx_1, dy_1, units="xy",scale=1)
plt.quiver(x_2,y_2, dx_2, dy_2, units="xy",scale=1,color="red")
plt.show()