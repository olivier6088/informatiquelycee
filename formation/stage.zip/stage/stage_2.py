import matplotlib.pyplot as plt
import numpy as np

x = np.arange(10)
y = x**2

plt.scatter(x,y, c="red",marker="+")
plt.show()
