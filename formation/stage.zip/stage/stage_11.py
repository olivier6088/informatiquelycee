import matplotlib.pyplot as plt
import numpy as np

x_1 = np.arange(1,10)
y_1 = x_1**2
y_2 = 1/x_1

x_2 = np.arange(0,4*3.14,0.1)
y_3 = np.sin(x_2)

plt.figure(figsize=(8,10))

plt.subplot(2,2,1)
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Graphe 1")
plt.scatter(x_1,y_1,marker="+",label="x^2")
plt.legend()

plt.subplot(2,2,2)
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Graphe 2")
plt.scatter(x_1,y_2,marker="+",label="1/X")
plt.legend()

plt.subplot(2,2,3)
plt.xlabel("X")
plt.ylabel("Y")
plt.title("Graphe 3")
plt.plot(x_2,y_3,label="sin(x)")
plt.legend()

plt.savefig("fig.png")
plt.show()
