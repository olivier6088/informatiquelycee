import matplotlib.pyplot as plt
import numpy as np

x = np.arange(101)
y = x**2

plt.plot(x,y)
plt.show()