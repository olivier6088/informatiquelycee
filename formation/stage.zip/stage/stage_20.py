import matplotlib.pyplot as plt
import numpy as np
import math

g = 9.81
m = 10
l = 10
nb_mesure=100
Dt = 0.05

vx=np.zeros(nb_mesure)
vz=np.zeros(nb_mesure)
v=np.zeros(nb_mesure)
vx[0]=0
vz[0]=0
v[0]=0
for i in range(1,nb_mesure):
    vx[i]=vx[i-1]
    vz[i]=vz[i-1]+(-g+(l/m)*math.fabs(vz[i-1]))*Dt 
    v[i]=np.sqrt(vx[i]**2+vz[i]**2)
    
t = np.arange(0,nb_mesure*Dt,Dt)
    
plt.figure(figsize=(8,8))
plt.xlabel("temps")
plt.ylabel("vitesse")
plt.scatter(t,v,marker="+")



